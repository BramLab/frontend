
var menuData = {};

async function loadMenu() {
    const response = await fetch('json/menus.json');
    menuData = await response.json();
    
    // Get gangen & fill select element:
    const gangenSelect = document.getElementById('gangen');
    const categories = Object.keys(menuData);
    gangenSelect.innerHTML = categories.map(
            gang => "<option value=\"" + gang + "\">" + gang + "</option>"
        ).join('');

    // Fill keuze with first category's items, even if nothing selected yet:
    if (categories.length > 0) {
        populateKeuze(categories[0]);
    }
}

loadMenu();

function populateKeuze(category) {							
    const keuzeSelect = document.getElementById('keuze');
    const keuze = menuData[category];
    
    keuzeSelect.innerHTML = keuze.map(
        item => "<option value=\"" + item.Naam + "\">" + item.Naam + "</option>"
    ).join('');
}

// Listen for category selection changes
document.getElementById('gangen').addEventListener('change', function() {
    populateKeuze(this.value);
});